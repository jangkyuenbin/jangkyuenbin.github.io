make knn
./knn -input ../data/mnist_features_only.txt -output ../data/knn_result.txt -samples 60000 -dim 784