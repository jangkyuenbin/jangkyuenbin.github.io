#include "Python.h"
#include "knn.h"

KNN model(10, 4);
const char *filename;

static PyObject *LoadFromFile(PyObject *self, PyObject *args)
{
    long long n_dim = -1;
	long long n_samples = -1;

    if (!PyArg_ParseTuple(args, "|sLL", &filename, &n_samples, &n_dim))
    {
        std::cout << "Input error!\n";
        return Py_None;
    }
    std::cout << filename << ", (" << n_samples << ", " << n_dim << ")" << std::endl;
    model.load_data(string(filename), n_samples, n_dim);
    return Py_None;
}

static PyObject *LoadFromData(PyObject *self, PyObject *args)
{
    PyObject *v;
    long long n_dim = -1;
	long long n_samples = -1;
    if (!PyArg_ParseTuple(args, "O", &v))
    {
        std::cout << "Input error!\n";
        return Py_None;
    }
    n_samples = PyList_Size(v);
    n_dim = PyList_Size(PyList_GetItem(v, 0));
    std::cout << "data shape = (" << n_samples << ", " << n_dim << ")" << std::endl;
    real *data = new real[n_samples * n_dim];
    std::cout << std::setprecision(2) << std::fixed;
    for (long long i = 0; i < n_samples; i++)
    {
        PyObject *vec = PyList_GetItem(v, i);
        if (i % 3000 == 0 || i == n_samples - 1)
		{
            std::cout << "Reading feature vectors " << i * 100.0 / n_samples << "%" << std::endl;
		}
		if (PyList_Size(vec) != n_dim)
		{
			printf("Input dimension error!\n");
			return Py_None;
		}
        for (long long j = 0; j < n_dim; j++)
        {
            // real x = atof(PyBytes_AS_STRING(PyObject_Str(PyList_GetItem(vec, j))));
            real x = (real)(PyFloat_AsDouble(PyList_GetItem(vec, j)));
            data[i * n_dim + j] = x;
        }
    }
    model.load_from_data(data, n_samples, n_dim);
    return Py_None;
}

static PyObject *ConstructKNN(PyObject *self, PyObject *args)
{
    int num_trees = -1; 
    int num_iter = -1;
    real perplexity = -1;
    if (!PyArg_ParseTuple(args, "nnfs", &num_trees, &num_iter, &perplexity, &filename))
    {
        std::cout << "Input error!\n";
        return Py_None;
    }
    model.construct_knn(num_trees, num_iter, perplexity);
    model.save_knn(filename);

    return Py_None;
}

static PyObject *SetNumThreads(PyObject *self, PyObject *args)
{
    int n_thread = 1;
    if(!PyArg_ParseTuple(args, "i", &n_thread))
    {
        std::cout << "Input error!\n";
        return Py_None;
    }
    model.set_n_thread(n_thread);
    return Py_None;
}

static PyObject *SetNumNeighbors(PyObject *self, PyObject *args)
{
    long long n_neigh = 1;
    if(!PyArg_ParseTuple(args, "L", &n_neigh))
    {
        std::cout << "Input error!\n";
        return Py_None;
    }
    model.set_n_neigh(n_neigh);
    return Py_None;
}


// Method table
static PyMethodDef PyExtMethods[] = 
{
    {"load_file", LoadFromFile, METH_VARARGS, "load_data(infile: str, n_samples: int, n_dim: int)\nLoad highdimensional data from a file with specific sample number and dimensionality."},
    {"load_data", LoadFromData, METH_VARARGS, "load_data()\nLoad highdimensional data from python list."},
    {"construct_knn", ConstructKNN, METH_VARARGS, "construct_knn(n_trees, n_propagation, perplexity)"},
    {"n_threads", SetNumThreads, METH_VARARGS, "n_threads(int n_thread)"},
    {"n_neighbors", SetNumNeighbors, METH_VARARGS, "n_neighbors(int n_neigh)"},
    { NULL, NULL, 0, NULL }             /* Sentinel */
};

// The method table must be referenced in the module definition structure
static struct PyModuleDef knnmodule = {
    PyModuleDef_HEAD_INIT,
    "knn",   /* name of module */
    NULL, /* module documentation, may be NULL */
    -1,       /* size of per-interpreter state of the module,
                 or -1 if the module keeps state in global variables. */
    PyExtMethods
};

// Initialization function
PyMODINIT_FUNC PyInit_KNN(void)
{
   // printf("knn successfully imported!\n");
    return PyModule_Create(&knnmodule);
    // Py_InitModule("knn", PyExtMethods);
}