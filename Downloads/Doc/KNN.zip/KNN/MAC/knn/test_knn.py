import KNN as knn
import pandas as pd

# knn.load_file("/Users/yale/Projects/research/gnnvis/data/mnist_features_only.txt", 60000, 784)

def load_from_file(filename):
    df = pd.read_csv(filename, sep=" ", header=None)
    data = df.values.tolist()
    return data

data = load_from_file('/Users/yale/Projects/research/gnnvis/data/mnist_features_only.txt')

knn.load_data(data)
knn.construct_knn(10, 3, 50.0, "/Users/yale/Projects/research/gnnvis/data/mnist_knn.txt")
