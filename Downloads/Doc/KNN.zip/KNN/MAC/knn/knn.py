from annoy import AnnoyIndex


class AnnoyKNN(object):
  annoy = None
  vec_len = -1
  metric = 'euclidean'
  is_loaded = False

  def __init__(self, vec_len, metric='euclidean', index_file=None):
    self.vec_len = vec_len
    self.metric = metric
    self.annoy = AnnoyIndex(self.vec_len, self.metric)
    if index_file:
      self.load(index_file)

  def get_nns_by_item(self, i, n, search_k=-1, include_distances=False):
    if self.is_loaded:
      return self.annoy.get_nns_by_item(i, n, search_k, include_distances)
    else:
      raise RuntimeError("Annoy index file is not loaded!")

  def get_nns_by_vector(self, v, n, search_k=-1, include_distances=False):
    if self.is_loaded:
      return self.annoy.get_nns_by_vector(v, n, search_k, include_distances)
    else:
      raise RuntimeError("Annoy index file is not loaded!")

  def load(self, index_file):
    self.annoy.load(index_file)
    self.is_loaded = True
  
  def unload(self):
    self.annoy.unload()
    self.is_loaded = False