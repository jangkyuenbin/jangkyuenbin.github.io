from distutils.core import setup, Extension
import os
import urllib
import zipfile

if os.getenv('BOOST_ROOT', 'None') == 'None':
    sourceFile = "D:\\boost_1_71_0.zip"
    targetPath = "D:\\boost_1_71_0"
    urllib.urlretrieve("https://dl.bintray.com/boostorg/release/1.71.0/source/boost_1_71_0.zip", sourceFile)
    file = zipfile.ZipFile(sourceFile, 'r')
    file.extractall(targetPath)
    print('success to unzip file!')
# os.environ["CC"] = "clang"
# os.environ["CXX"] = "clang++"
os.getenv('not_existing_variable', 'that variable does not exist')

#os.environ["CC"] = "g++"
#os.environ["CXX"] = "g++"
print('BOOST_ROOT: ', os.getenv('BOOST_ROOT', 'D:\\boost_1_71_0'))
print('BOOST_LIB: ', os.getenv('BOOST_LIB', 'D:\\boost_1_71_0\\stage\\lib'))

KNN = Extension('KNN',
                sources=['knn.cpp', 'knnmodule.cpp', 'ANNOY\\mman.cpp'],
                depends=['knn.h'],
                include_dirs=[os.getenv('BOOST_ROOT', 'D:\\boost_1_58_0')],
                library_dirs=[os.getenv('BOOST_LIB', 'D:\\boost_1_58_0\\stage\\lib')],
                extra_compile_args=['/Ox'])

setup(name='KNN',
      version='0.1',
      description='KNN',
      ext_modules=[KNN],
      )
