import KNN
import pandas as pd
from sklearn.datasets import fetch_openml

# knn.load_file("/Users/yale/Projects/research/gnnvis/data/mnist_features_only.txt", 60000, 784)

def load_mnist(loadsize):
    mnist = fetch_openml('mnist_784')
    Xs = mnist.data[:int(loadsize), :]
    labels = mnist.target[:int(loadsize)]

    return Xs.tolist()

def load_from_file(filename):
    df = pd.read_csv(filename, sep=" ", header=None)
    data = df.values.tolist()
    return data

if __name__ == '__main__':
    data = load_mnist(10000)
    KNN.n_neighbors(5)
    KNN.load_data(data)
    KNN.construct_knn(10, 3, 50.0, "./data/mnist_knn.txt")


    # data = load_from_file('/Users/yale/Projects/research/gnnvis/data/mnist_features_only.txt')
    #
    # knn.load_data(data)
    # knn.construct_knn(10, 3, 50.0, "/Users/yale/Projects/research/gnnvis/data/mnist_knn.txt")
    pass
